from setuptools import setup
import setuptools

setup(
    name='calculator_projet',
    version='0.0.1',
    author="Evan Tassel",
    description="calculator_project is a simple package that \
    make some test on calculator packaging in python",
    license='None',
    python_requires='>=3.4',
    packages=['Calculator'],
)

